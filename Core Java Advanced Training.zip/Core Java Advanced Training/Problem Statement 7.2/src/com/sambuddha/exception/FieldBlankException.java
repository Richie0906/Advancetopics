package com.sambuddha.exception;
public class FieldBlankException extends Exception{
	
	public FieldBlankException(String mssg) {
		
		super(mssg);
	}

}
